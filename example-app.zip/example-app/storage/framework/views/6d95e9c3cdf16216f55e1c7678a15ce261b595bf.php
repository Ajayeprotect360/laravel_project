

<?php $__env->startSection('content'); ?>
    <h1>Student Details</h1>
    <div>
        <strong>Name:</strong> <?php echo e($student->student_id); ?>

    </div>
    <div>
        <strong>Email:</strong> <?php echo e($student->student_name); ?>

    </div>
    <div>
        <strong>Age:</strong> <?php echo e($student->class); ?>

    </div>
    <a href="<?php echo e(route('students.index')); ?>" class="btn btn-primary">Back to List</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\example-app\resources\views/students/show.blade.php ENDPATH**/ ?>