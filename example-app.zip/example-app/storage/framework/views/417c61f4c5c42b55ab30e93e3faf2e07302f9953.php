

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Student Created Successfully</div>

                <div class="card-body">
                    <div class="alert alert-success" role="alert">
                        The student has been successfully added to the database.
                    </div>

                    <h4>Student Details:</h4>
                    <ul>
                        <li><strong>Name:</strong> <?php echo e($student->student_name); ?></li>
                        <li><strong>Class:</strong> <?php echo e($student->class); ?></li>
                        <li><strong>Admission Date:</strong> <?php echo e($student->admission_date->format('Y-m-d')); ?></li>
                        <li><strong>Yearly Fees:</strong> <?php echo e(number_format($student->yearly_fees, 2)); ?></li>
                    </ul>

                    <div class="mt-3">
                        <a href="<?php echo e(route('students.index')); ?>" class="btn btn-primary">Back to Students List</a>
                        <a href="<?php echo e(route('students.create')); ?>" class="btn btn-success">Add Another Student</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\example-app\resources\views/students/stored.blade.php ENDPATH**/ ?>