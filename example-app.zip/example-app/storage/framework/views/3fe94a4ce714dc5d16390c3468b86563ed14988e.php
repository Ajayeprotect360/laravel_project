

<?php $__env->startSection('content'); ?>
<h1>Students</h1>
<a href="<?php echo e(route('students.create')); ?>" class="btn btn-primary">Add New Student</a>

<?php if($message = Session::get('success')): ?>
<div class="alert alert-success">
    <p><?php echo e($message); ?></p>
</div>
<?php endif; ?>

<!-- Search Form -->
<form method="GET" action="<?php echo e(route('students.index')); ?>" class="mb-3">
    <div class="input-group">
        <input type="text" name="search" class="form-control" placeholder="Search students..." value="<?php echo e($search); ?>">
        <button type="submit" class="btn btn-primary">Search</button>
    </div>
</form>

<!-- Students Table -->
<table class="table">
    <thead>
        <tr>
            <th>Name</th>
            <th>Grade</th>
            <th>Teacher</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($student->student_name); ?></td>
            <td><?php echo e($student->class); ?></td>
            <td>
                <?php
                    // Find the teacher by the class_teacher_id
                    $teacherName = $teachers->firstWhere('id', $student->class_teacher_id)->name ?? 'N/A';
                ?>
                <?php echo e($teacherName); ?>

            </td>
            <td>
                <a href="<?php echo e(route('students.show', $student->student_id)); ?>" class="btn btn-info">View</a>
                <a href="<?php echo e(route('students.edit', $student->student_id)); ?>" class="btn btn-primary">Edit</a>
                <form action="<?php echo e(route('students.destroy', $student->student_id)); ?>" method="POST" style="display: inline-block;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
            <td colspan="4" class="text-center">No students found</td>
        </tr>
        <?php endif; ?>
    </tbody>
</table>

<!-- Pagination Controls -->
<?php echo e($students->links()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\admin\example-app\resources\views/students/index.blade.php ENDPATH**/ ?>