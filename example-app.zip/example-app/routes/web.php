<?php

use App\Http\Controllers\StudentController;
use App\Http\Controllers\TeacherController;
use Illuminate\Support\Facades\Route;





Route::resource('students', StudentController::class);
Route::resource('teachers', TeacherController::class);
Route::get('./students/show', [StudentController::class, 'show'])->name('students.show');
Route::get('/students/edit/{student_id}', [StudentController::class, 'edit'])->name('students.edit');
Route::get('./students/stored', [StudentController::class, 'stored'])->name('students.stored');
Route::delete('/students/destroy/{student_id}', [StudentController::class, 'destroy'])->name('students.destroy');
Route::get('/',[ StudentController::class,'index'])->name('students.index');


