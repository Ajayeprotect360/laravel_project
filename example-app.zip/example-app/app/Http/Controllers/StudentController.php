<?php

namespace App\Http\Controllers;

use App\Models\Student;
use App\Models\Teacher;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class StudentController extends Controller
{
    public function index(Request $request)
    {
        // Get the search query from the request
        $search = $request->input('search', '');

        // Fetch students with search, pagination, and soft deletion check
        $students = DB::table('students')
            ->where(function ($query) use ($search) {
                $query->where('student_name', 'like', "%{$search}%")
                    ->orWhere('class', 'like', "%{$search}%")
                    ->orWhere('class_teacher_id', 'like', "%{$search}%"); // Adjust if necessary
            })
            ->where('deleted', 0) // Fetch only records where deleted_at is null
            ->paginate(10); // Adjust the number of items per page as needed
        $teachers = DB::table('teachers')->get();
        return view('students.index', compact('students','search','teachers'));
    }

    public function create()
    {
        // Fetch teachers from the database
        $teachers = DB::table('teachers')->get();

        // Pass the teachers to the view
        return view('students.create', compact('teachers'));
    }

    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'student_name' => 'required|string|max:255',
            'class_teacher_id' => 'required|exists:teachers,id',
            'class' => 'required|string|max:50',
            'admission_date' => 'required|date',
            'yearly_fees' => 'required|numeric|min:0',
        ]);

        $student = Student::create($validatedData);

        // Load the class teacher relationship
        $student->load('classTeacher');

        // Return the 'stored' view instead of redirecting
        return view('students.stored', compact('student'));
    }

    public function show(Student $student)
    {
        $student = DB::table('students')->get();
        return view('students.show', compact('students'));
    }

    public function edit(Request $request, $student_id)
    {
        // Retrieve the student by ID
        $student = DB::table('students')
            ->where('student_id', $student_id)
            ->first();

        // Retrieve all teachers
        $teachers = DB::table('teachers')->get();

        // Check if student exists
        if ($student) {
            return view('students.edit', compact('student', 'teachers'));
        } else {
            return redirect()->route('students.index')->with('error', 'Student not found');
        }
    }




    public function update(Request $request, $id)
    {
        $validatedData = $request->validate([
            'student_name' => 'required|string|max:255',
            'class_teacher_id' => 'required|exists:teachers,id',
            'class' => 'required|string|max:50',
            'admission_date' => 'required|date',
            'yearly_fees' => 'required|numeric|min:0',
        ]);
        $student = DB::table('students');
        $student->update($validatedData);
        return redirect()->route('students.index')->with('success', 'Student updated successfully.');
    }

    public function destroy(Request $request, $id)
    {
        // Fetch the student record
        $student = DB::table('students')
            ->where('student_id', $id)
            ->first();

        if ($student) {
            // Update the `deleted` column to `1`
            DB::table('students')
                ->where('student_id', $id)
                ->update(['deleted' => 1]);

            return redirect()->route('students.index')->with('success', 'Student marked as deleted successfully.');
        } else {
            // return redirect()->route('students.index')->with('error', 'Student not found.');
        }
    }
}
