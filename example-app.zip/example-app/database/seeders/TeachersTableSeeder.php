<?php

namespace Database\Seeders;

use App\Models\Teacher;
use Illuminate\Database\Seeder;

class TeachersTableSeeder extends Seeder
{
    public function run()
    {
        Teacher::create([
            'name' => 'John Doe',
            'email' => 'john.doe@example.com',
            'subject' => 'Mathematics',
        ]);

        Teacher::create([
            'name' => 'Jane Smith',
            'email' => 'jane.smith@example.com',
            'subject' => 'English',
        ]);

        Teacher::create([
            'name' => 'Bob Johnson',
            'email' => 'bob.johnson@example.com',
            'subject' => 'Science',
        ]);
    }
}