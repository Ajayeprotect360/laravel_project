@extends('layouts.app')

@section('content')
    <h1>Student Details</h1>
    <!-- <div>
        <strong>Name:</strong> {{ $student->student_id }}
    </div>
    <div>
        <strong>Email:</strong> {{ $student->student_name }}
    </div>
    <div>
        <strong>Age:</strong> {{ $student->class }}
    </div> -->
    <a href="{{ route('students.index') }}" class="btn btn-primary">Back to List</a>
@endsection