@extends('layouts.app')

@section('content')
<h1>Students</h1>
<a href="{{ route('students.create') }}" class="btn btn-primary">Add New Student</a>

@if ($message = Session::get('success'))
<div class="alert alert-success">
    <p>{{ $message }}</p>
</div>
@endif

<!-- Search Form -->
<form method="GET" action="{{ route('students.index') }}" class="mb-3">
    <div class="input-group">
        <input type="text" name="search" class="form-control" placeholder="Search students..." value="{{ $search }}">
        <button type="submit" class="btn btn-primary">Search</button>
    </div>
</form>

<!-- Students Table -->
<table class="table">
    <thead>
        <tr>
            <th>Name</th>
            <th>Grade</th>
            <th>Teacher</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        @forelse ($students as $student)
        <tr>
            <td>{{ $student->student_name }}</td>
            <td>{{ $student->class }}</td>
            <td>
                @php
                    // Find the teacher by the class_teacher_id
                    $teacherName = $teachers->firstWhere('id', $student->class_teacher_id)->name ?? 'N/A';
                @endphp
                {{ $teacherName }}
            </td>
            <td>
                <a href="{{ route('students.show', $student->student_id) }}" class="btn btn-info">View</a>
                <a href="{{ route('students.edit', $student->student_id) }}" class="btn btn-primary">Edit</a>
                <form action="{{ route('students.destroy', $student->student_id) }}" method="POST" style="display: inline-block;">
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete</button>
                </form>
            </td>
        </tr>
        @empty
        <tr>
            <td colspan="4" class="text-center">No students found</td>
        </tr>
        @endforelse
    </tbody>
</table>

<!-- Pagination Controls -->
{{ $students->links() }}
@endsection