@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Student Created Successfully</div>

                <div class="card-body">
                    <div class="alert alert-success" role="alert">
                        The student has been successfully added to the database.
                    </div>

                    <h4>Student Details:</h4>
                    <ul>
                        <li><strong>Name:</strong> {{ $student->student_name }}</li>
                        <li><strong>Class:</strong> {{ $student->class }}</li>
                        <li><strong>Admission Date:</strong> {{ $student->admission_date->format('Y-m-d') }}</li>
                        <li><strong>Yearly Fees:</strong> {{ number_format($student->yearly_fees, 2) }}</li>
                    </ul>

                    <div class="mt-3">
                        <a href="{{ route('students.index') }}" class="btn btn-primary">Back to Students List</a>
                        <a href="{{ route('students.create') }}" class="btn btn-success">Add Another Student</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection