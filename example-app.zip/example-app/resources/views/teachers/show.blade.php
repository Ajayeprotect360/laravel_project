@extends('layouts.app')

@section('content')
    <h1>Teacher Details</h1>
    <div>
        <strong>Name:</strong> {{ $teacher->name }}
    </div>
    <div>
        <strong>Email:</strong> {{ $teacher->email }}
    </div>
    <div>
        <strong>Subject:</strong> {{ $teacher->subject }}
    </div>
    <a href="{{ route('teachers.index') }}" class="btn btn-primary mt-3">Back to List</a>
@endsection